#ifndef DATABUILDER_H
#define DATABUILDER_H

#include <QVector>
#include <QAbstractListModel>

class DataBuilder
{
public:
    DataBuilder();
    int build();
};

#endif // DATABUILDER_H
