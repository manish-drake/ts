#include "asynchdatop.h"

AsynchDatOp::AsynchDatOp()
{

}
