#ifndef ASYNCHDATOP_H
#define ASYNCHDATOP_H


class AsynchDatOp
{
public:
    AsynchDatOp();
};

#endif // ASYNCHDATOP_H