#include "controlnavigation.h"

ControlNavigation::ControlNavigation()
{

}
