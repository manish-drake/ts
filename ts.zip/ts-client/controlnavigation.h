#ifndef CONTROLNAVIGATION_H
#define CONTROLNAVIGATION_H


class ControlNavigation
{
public:
    ControlNavigation();
};

#endif // CONTROLNAVIGATION_H